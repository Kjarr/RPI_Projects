#!/bin/sh

sudo ./pifmrds -freq "$1" -audio src/pifmrds/stereo_44100.wav
