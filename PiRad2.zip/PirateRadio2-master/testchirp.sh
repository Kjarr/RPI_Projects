#!/bin/sh

sudo ./pichirp "$1" 100000 5

