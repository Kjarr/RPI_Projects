#!/bin/sh

sudo ./freedv src/freedv/VCO800XA.rf "$1" 400
